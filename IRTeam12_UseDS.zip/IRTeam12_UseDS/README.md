# Dense + SASRec Recommendation System (Instacart)

This repository contains an implementation of a **next-item recommendation system** using a hybrid approach:
- Dense Retrieval (Sentence-BERT)
- Sequential Recommendation (SASRec)

The code trains a SASRec model and evaluates recommendations for different user groups on the Instacart dataset.

---

## 1. Directory Structure

```
.
├── team12_DS2.py                  # Main training & evaluation script
├── README.md
└── instacart_data/
    ├── orders.csv
    ├── order_products__prior.csv
    ├── products.csv
    ├── aisles.csv
    └── departments.csv
```

---

## 2. Requirements

### Python Version
- Python **3.8+** recommended

### Required Libraries

Install dependencies with:

```bash
pip install torch sentence-transformers scikit-learn pandas tqdm
```

### Optional (GPU)

- CUDA-enabled GPU is supported
- If CUDA is unavailable, the code will automatically fall back to CPU

---

## 3. Dataset Preparation

Download the Instacart dataset from Kaggle:

https://www.kaggle.com/datasets/yasserh/instacart-online-grocery-basket-analysis-dataset

Place the following files under `./instacart_data/`:

- `orders.csv`
- `order_products__prior.csv`
- `products.csv`
- `aisles.csv`
- `departments.csv`

No additional preprocessing is required.

---

## 4. Configuration

Key configuration parameters (editable in `main.py`):

```python
MAX_LEN = 50
MAX_EVAL_USERS = 500
LOG_EVERY = 100
```

---

## 5. How to Run

```bash
python team12_DS2.py
```

---

## 6. Training Details

- Model: SASRec
- Loss: CrossEntropyLoss
- Optimizer: Adam
- Epochs: 5
- Batch size: 128

---

## 7. Evaluation Output

The script prints Recall@K and NDCG@K for different user groups.

---

## 8. Logging

Progress is printed every `LOG_EVERY` users during evaluation.

---

## 9. Notes

- Dense retrieval uses cosine similarity
- SASRec uses only item IDs
- Cold users rely on dense retrieval only

---

## 10. Limitations

- No validation split
- No fine-tuning of Sentence-BERT
- One ground-truth item per user
